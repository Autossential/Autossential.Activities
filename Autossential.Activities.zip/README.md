# Autossential.Activities
Provides a collection of activities to work with DataTables, Collections, Files, Programming, Workflows, Security and Diagnostics.
