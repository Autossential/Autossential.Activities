# Autossential.Shared
The shared code used on Autossential packages.
