﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for CleanUpFolderDesigner.xaml
    public partial class CleanUpFolderDesigner
    {
        public CleanUpFolderDesigner()
        {
            InitializeComponent();
        }
    }
}
