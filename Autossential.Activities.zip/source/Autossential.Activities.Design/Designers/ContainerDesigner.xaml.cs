﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for ContainerDesigner.xaml
    public partial class ContainerDesigner
    {
        public ContainerDesigner()
        {
            InitializeComponent();
        }
    }
}