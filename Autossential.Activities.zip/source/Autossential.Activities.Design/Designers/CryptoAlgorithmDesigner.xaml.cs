﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for CryptoAlgorithmDesigner.xaml
    public partial class CryptoAlgorithmDesigner
    {
        public CryptoAlgorithmDesigner()
        {
            InitializeComponent();
        }
    }
}
