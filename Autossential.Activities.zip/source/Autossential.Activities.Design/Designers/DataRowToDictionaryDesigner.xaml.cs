﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for DataRowToDictionaryDesigner.xaml
    public partial class DataRowToDictionaryDesigner
    {
        public DataRowToDictionaryDesigner()
        {
            InitializeComponent();
        }
    }
}