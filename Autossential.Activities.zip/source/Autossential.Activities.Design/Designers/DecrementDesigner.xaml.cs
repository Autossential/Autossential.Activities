﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for DecrementDesigner.xaml
    public partial class DecrementDesigner
    {
        public DecrementDesigner()
        {
            InitializeComponent();
        }
    }
}