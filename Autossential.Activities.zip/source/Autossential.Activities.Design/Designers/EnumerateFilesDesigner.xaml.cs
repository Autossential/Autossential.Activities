﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for EnumerateFilesDesigner.xaml
    public partial class EnumerateFilesDesigner
    {
        public EnumerateFilesDesigner()
        {
            InitializeComponent();
        }
    }
}