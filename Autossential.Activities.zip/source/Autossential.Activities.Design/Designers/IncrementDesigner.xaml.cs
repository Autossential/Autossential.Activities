﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for IncrementDesigner.xaml
    public partial class IncrementDesigner
    {
        public IncrementDesigner()
        {
            InitializeComponent();
        }
    }
}