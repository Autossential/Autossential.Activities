﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for IsTrueDesigner.xaml
    public partial class IsTrueDesigner
    {
        public IsTrueDesigner()
        {
            InitializeComponent();
        }
    }
}
