﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for NextDesigner.xaml
    public partial class NextDesigner
    {
        public NextDesigner()
        {
            InitializeComponent();
        }
    }
}