﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for PromoteHeadersDesigner.xaml
    public partial class PromoteHeadersDesigner
    {
        public PromoteHeadersDesigner()
        {
            InitializeComponent();
        }
    }
}