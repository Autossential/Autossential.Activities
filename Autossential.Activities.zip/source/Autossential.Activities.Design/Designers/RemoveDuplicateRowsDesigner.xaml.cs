﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for RemoveDuplicateRowsDesigner.xaml
    public partial class RemoveDuplicateRowsDesigner
    {
        public RemoveDuplicateRowsDesigner()
        {
            InitializeComponent();
        }
    }
}
