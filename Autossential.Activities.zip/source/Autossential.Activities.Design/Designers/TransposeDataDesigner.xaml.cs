﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for TransposeData.xaml
    public partial class TransposeDataDesigner
    {
        public TransposeDataDesigner()
        {
            InitializeComponent();
        }
    }
}
