﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for UnzipDesigner.xaml
    public partial class UnzipDesigner
    {
        public UnzipDesigner()
        {
            InitializeComponent();
        }
    }
}