﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for WaitDynamicFileDesigner.xaml
    public partial class WaitDynamicFileDesigner
    {
        public WaitDynamicFileDesigner()
        {
            InitializeComponent();
        }
    }
}
