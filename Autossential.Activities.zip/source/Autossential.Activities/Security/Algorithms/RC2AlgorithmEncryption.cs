﻿using Autossential.Core.Security.Algorithms;

namespace Autossential.Activities.Security.Algorithms
{
    public sealed class RC2AlgorithmEncryption : SymmetricAlgorithmEncryptionBase<RC2Encryption> { }

}

