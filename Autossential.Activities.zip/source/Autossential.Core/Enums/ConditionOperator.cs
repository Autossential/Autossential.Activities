﻿namespace Autossential.Core.Enums
{
    public enum ConditionOperator
    {
        And,
        Or
    }
}