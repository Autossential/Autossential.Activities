﻿namespace Autossential.Core.Enums
{
    public enum CryptoActions
    {
        Encrypt,
        Decrypt
    }
}