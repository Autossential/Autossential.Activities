﻿namespace Autossential.Core.Enums
{
    public enum DataRowEvaluationMode
    {
        All,
        Any,
        Custom
    }
}