﻿namespace Autossential.Core.Enums
{
    public enum StopwatchMethods
    {
        Start = 0,
        Stop = 1,
        Reset = 2,
        Restart = 3
    }
}