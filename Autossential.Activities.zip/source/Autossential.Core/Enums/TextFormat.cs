﻿namespace Autossential.Core.Enums
{
    public enum TextFormat
    {
        HTML,
        JSON,
        XML
    }
}
